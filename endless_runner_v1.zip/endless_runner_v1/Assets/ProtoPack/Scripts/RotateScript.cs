﻿using UnityEngine;
using System.Collections;

public class RotateScript : MonoBehaviour {

	void Update () {
	
		transform.Rotate (Vector3.up*5);

	}
}
